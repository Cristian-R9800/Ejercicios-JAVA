/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SessionBean;

import javax.ejb.Local;

/**
 *
 * @author crist
 */
@Local
public interface calcbeanLocal {

    Double addition(double a, double b);

    Double subtract(double a, double b);

    Double multiply(double a, double b);

    Double divide(double a, double b);
    
}
