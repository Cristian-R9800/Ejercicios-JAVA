/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.CRUD.Estudiante.servlet;

import co.edu.unipiloto.CRUD.Estudiante.entity.Courses;
import co.edu.unipiloto.CRUD.Estudiante.entity.Estudiantes;
import co.edu.unipiloto.CRUD.Estudiante.entity.Studentcourses;
import co.edu.unipiloto.CRUD.Estudiante.session.CoursesFacadeLocal;
import co.edu.unipiloto.CRUD.Estudiante.session.EstudiantesFacadeLocal;
import co.edu.unipiloto.CRUD.Estudiante.session.StudentcoursesFacadeLocal;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author crist
 */
public class StudentServlet extends HttpServlet {

    @EJB
    private StudentcoursesFacadeLocal studentcoursesFacade;

    @EJB
    private CoursesFacadeLocal coursesFacade;

    @EJB
    private EstudiantesFacadeLocal estudiantesFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String action = request.getParameter("action");
            Estudiantes estuden=null;
            if (!("newCourse".equalsIgnoreCase(action)) && !("linkcourse".equalsIgnoreCase(action)) && !("Actualizar".equalsIgnoreCase(action))) {
                String studentIdstr = request.getParameter("studentId");
                int studentId = Integer.parseInt(studentIdstr);
                String firstname = request.getParameter("firstName");
                String lastname = request.getParameter("lastName");
                String yearlevelStr = request.getParameter("yearLevel");
                int yearlevel = Integer.parseInt(yearlevelStr);
                System.out.println(studentId + "-" + action);
                estuden = new Estudiantes(studentId, firstname, lastname, yearlevel);

                if ("Add".equalsIgnoreCase(action)) {
                    estudiantesFacade.create(estuden);
                } else if ("Edit".equalsIgnoreCase(action)) {
                    estudiantesFacade.edit(estuden);
                } else if ("Delete".equalsIgnoreCase(action)) {
                    estudiantesFacade.remove(estuden);
                } else if ("Search".equalsIgnoreCase(action)) {
                    estuden = estudiantesFacade.find(studentId);
                    request.setAttribute("student", estuden);
                }
            } else if ("newCourse".equalsIgnoreCase(action)) {

                //String courseId = request.getParameter("courseId");
                String name = request.getParameter("name");
                int credits = Integer.parseInt(request.getParameter("credits"));
                int semester = Integer.parseInt(request.getParameter("semester"));
                int allStudents = Integer.parseInt(request.getParameter("allStudents"));
                Courses curso = new Courses(name, name, credits, semester, allStudents);
                coursesFacade.create(curso);
            } else if ("linkcourse".equalsIgnoreCase(action)) {
                int studentId = Integer.parseInt(request.getParameter("studentId"));
                int idLink = Integer.parseInt(request.getParameter("idLink"));
                String courseId = request.getParameter("courseIdC");
                Courses cursol = coursesFacade.find(courseId);
                Estudiantes studentl = estudiantesFacade.find(studentId);
                Studentcourses enlace = new Studentcourses(idLink, cursol, studentl);
                studentcoursesFacade.create(enlace);
            }
           
            
            request.setAttribute("allCoursesS",studentcoursesFacade.findAll());
            request.setAttribute("allCourses", coursesFacade.findAll());
            request.setAttribute("allStudents", estudiantesFacade.findAll());
            request.getRequestDispatcher("studentInfo.jsp").forward(request, response);

         
        }
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
