/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.CRUD.Estudiante.entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author crist
 */
@Entity
@Table(name = "COURSES")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Courses.findAll", query = "SELECT c FROM Courses c"),
    @NamedQuery(name = "Courses.findByCoursesid", query = "SELECT c FROM Courses c WHERE c.coursesid = :coursesid"),
    @NamedQuery(name = "Courses.findByName", query = "SELECT c FROM Courses c WHERE c.name = :name"),
    @NamedQuery(name = "Courses.findByCredits", query = "SELECT c FROM Courses c WHERE c.credits = :credits"),
    @NamedQuery(name = "Courses.findBySemester", query = "SELECT c FROM Courses c WHERE c.semester = :semester"),
    @NamedQuery(name = "Courses.findByAllowedstudents", query = "SELECT c FROM Courses c WHERE c.allowedstudents = :allowedstudents")})
public class Courses implements Serializable {

    @OneToMany(mappedBy = "coursePk")
    private Collection<Studentcourses> studentcoursesCollection;

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "COURSESID")
    private String coursesid;
    @Size(max = 40)
    @Column(name = "NAME")
    private String name;
    @Column(name = "CREDITS")
    private Integer credits;
    @Column(name = "SEMESTER")
    private Integer semester;
    @Column(name = "ALLOWEDSTUDENTS")
    private Integer allowedstudents;
    @JoinTable(name = "STUDENTCOURSES", joinColumns = {
        @JoinColumn(name = "COURSEID", referencedColumnName = "COURSESID")}, inverseJoinColumns = {
        @JoinColumn(name = "STUDENTID", referencedColumnName = "STUDENTID")})
    @ManyToMany
    private Collection<Estudiantes> estudiantesCollection;

    public Courses() {
    }

    public Courses(String coursesid, String name, int credits, int semester, int allowedStudents) {
        this.coursesid = coursesid;
        this.name = name;
        this.credits = credits;
        this.semester = semester;
        this.allowedstudents = allowedStudents;

    }

    public String getCoursesid() {
        return coursesid;
    }

    public void setCoursesid(String coursesid) {
        this.coursesid = coursesid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCredits() {
        return credits;
    }

    public void setCredits(Integer credits) {
        this.credits = credits;
    }

    public Integer getSemester() {
        return semester;
    }

    public void setSemester(Integer semester) {
        this.semester = semester;
    }

    public Integer getAllowedstudents() {
        return allowedstudents;
    }

    public void setAllowedstudents(Integer allowedstudents) {
        this.allowedstudents = allowedstudents;
    }

    @XmlTransient
    public Collection<Estudiantes> getEstudiantesCollection() {
        return estudiantesCollection;
    }

    public void setEstudiantesCollection(Collection<Estudiantes> estudiantesCollection) {
        this.estudiantesCollection = estudiantesCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (coursesid != null ? coursesid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Courses)) {
            return false;
        }
        Courses other = (Courses) object;
        if ((this.coursesid == null && other.coursesid != null) || (this.coursesid != null && !this.coursesid.equals(other.coursesid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "co.edu.unipiloto.CRUD.Estudiante.entity.Courses[ coursesid=" + coursesid + " ]";
    }

    @XmlTransient
    public Collection<Studentcourses> getStudentcoursesCollection() {
        return studentcoursesCollection;
    }

    public void setStudentcoursesCollection(Collection<Studentcourses> studentcoursesCollection) {
        this.studentcoursesCollection = studentcoursesCollection;
    }

}
