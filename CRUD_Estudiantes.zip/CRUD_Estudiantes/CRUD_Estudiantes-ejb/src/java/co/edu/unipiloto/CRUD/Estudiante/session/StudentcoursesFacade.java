/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.CRUD.Estudiante.session;

import co.edu.unipiloto.CRUD.Estudiante.entity.Studentcourses;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author crist
 */
@Stateless
public class StudentcoursesFacade extends AbstractFacade<Studentcourses> implements StudentcoursesFacadeLocal {

    @PersistenceContext(unitName = "CRUD_Estudiantes-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public StudentcoursesFacade() {
        super(Studentcourses.class);
    }
    
}
