/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.CRUD.Estudiante.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author crist
 */
@Entity
@Table(name = "STUDENTCOURSES")
@XmlRootElement 
@NamedQueries({
    @NamedQuery(name = "Studentcourses.findAll", query  = "SELECT s.id,s.studentPk,s.studentPk FROM Studentcourses s"),
    @NamedQuery(name = "Studentcourses.findById", query = "SELECT s FROM Studentcourses s WHERE s.id = :id")}) 
public class Studentcourses implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Integer id;
    @JoinColumn(name = "COURSE_PK", referencedColumnName = "COURSESID")
    @ManyToOne
    private Courses coursePk;
    @JoinColumn(name = "STUDENT_PK", referencedColumnName = "STUDENTID")
    @ManyToOne
    private Estudiantes studentPk;

    public Studentcourses() {
    
    }
    public Studentcourses(int id, Courses course, Estudiantes student) {
        this.id = id;
        this.coursePk = course;
        this.studentPk = student;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Courses getCoursePk() {
        return coursePk;
    }

    public void setCoursePk(Courses coursePk) {
        this.coursePk = coursePk;
    }

    public Estudiantes getStudentPk() {
        return studentPk;
    }

    public void setStudentPk(Estudiantes studentPk) {
        this.studentPk = studentPk;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Studentcourses)) {
            return false;
        }
        Studentcourses other = (Studentcourses) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "co.edu.unipiloto.CRUD.Estudiante.entity.Studentcourses[ id=" + id + " ]";
    }

}
