Se creo la tabla studentcourses con el fin de establecer la relación entre las tablas course y student,
se habilita la creacion de cursos y se da la posibilidad de anexar un estudiante mediante su id al curso
deseado anexando a su vez un id unico para relacionarlos, se anexan los archivos de la base de datos y 
screenshots de su funcionamiento, el unico problema encontrado es la consulta cruzada de estudiante y 
cursos pues aunque se consulte por medio de un join solo retorna al jsp el id de la relación estudiante-curso


 
