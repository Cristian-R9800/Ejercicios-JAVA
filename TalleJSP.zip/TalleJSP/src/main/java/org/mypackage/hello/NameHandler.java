/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.mypackage.hello;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author cristian
 */
public class NameHandler {

    private String name;
    private String birthday;
    private int year;

    public NameHandler() {
        name = null;
        year = 0;
        birthday = null;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) throws ParseException { // se calcula la edad de la persona
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date fechaInicial = dateFormat.parse(birthday);
        String a = ((System.currentTimeMillis() - fechaInicial.getTime()) / 86400000 / 365) + "";
        this.birthday = a;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) throws ParseException {// se calculan los semestres cursados
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date ingreso = dateFormat.parse(year + "-02-01");
        Long a = ((System.currentTimeMillis() - ingreso.getTime()) / 86400000 / 365) * 2;
        this.year = (int) Math.floor(a);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
